﻿using System.Configuration;
using System.Web.Mvc;
using HyperDemo.Config;
using HyperDemo.Data;
using HyperDemo.Services;
using HyperIoC;
using HyperIoC.Mvc;

namespace HyperDemo.Web
{
    public class ContainerConfig
    {
        public static Factory Factory { get; private set; }

        public static void RegisterContainer()
        {
            var config = ConfigurationManager.AppSettings["Config"] ?? "DEBUG";

            Factory = FactoryBuilder
                .Build()
                .WithProfile<AnyProfile>()
                .WithProfile<DebugProfile>(() => config == "DEBUG")
                .WithProfile<ReleaseProfile>(() => config == "RELEASE")
                .Create();

            ControllerBuilder.Current.SetControllerFactory(new HyperIoCControllerFactory(Factory));
        }

        public class AnyProfile : FactoryProfile
        {
            public override void Construct(IFactoryBuilder builder)
            {
                builder.Add<IUserService, UserService>();
                builder.Add<IAppSettings, AppSettings>().AsSingleton();
                builder.AddControllers(typeof(MvcApplication).Assembly);
            }
        }

        public class DebugProfile : FactoryProfile
        {
            public override void Construct(IFactoryBuilder builder)
            {
                builder.Add<IUserRepository, InMemoryUserRepository>().AsSingleton();
            }
        }

        public class ReleaseProfile : FactoryProfile
        {
            public override void Construct(IFactoryBuilder builder)
            {
                builder.Add<IUserRepository, DiskUserRepository>().AsSingleton();
            }
        }
    }
}
