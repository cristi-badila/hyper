﻿var app = angular.module('demo', []);

app.config(['$httpProvider', function($httpProvider) {

        $httpProvider.interceptors.push(function($q) {
            return {
                'requestError': function(rejection) {
                    // TODO: Add service for standard errors
                    return $q.reject(rejection);
                },

                'responseError': function(rejection) {
                    // TODO: Add service for standard errors
                    return $q.reject(rejection);
                }
            };
        });
    }
]);

app.controller('HomeController', [
    '$scope', '$http', function($scope, $http) {

        var urlBase = 'http://localhost:50594/api/home';
        $scope.users = [];

        $http.get(urlBase + '/users').then(function (response) {
            $scope.users = response.data;
        });
    }
]);