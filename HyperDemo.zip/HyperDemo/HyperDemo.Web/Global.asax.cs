﻿using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using HyperDemo.Data;

namespace HyperDemo.Web
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            ContainerConfig.RegisterContainer();

            AddTestData();
        }

        private static void AddTestData()
        {
            var userRepository = ContainerConfig.Factory.Get<IUserRepository>();
            userRepository.Create("Homer Simpson");
            userRepository.Create("Marge Simpson");
            userRepository.Create("Bart Simpson");
            userRepository.Create("Lisa Simpson");
            userRepository.Create("Maggie Simpson");
        }
    }
}
