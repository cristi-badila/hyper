﻿using System.Linq;
using System.Web.Mvc;
using HyperDemo.Services;

namespace HyperDemo.Web.Controllers
{
    [RoutePrefix("api/home")]
    public class HomeApiController : Controller
    {
        private readonly IUserService _userService;

        public HomeApiController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        [Route("users")]
        public ActionResult GetUsers()
        {
            // A bit naughty (JSON VUN) but OK for demo!
            return Json(_userService.GetUsers().ToList(), JsonRequestBehavior.AllowGet);
        }
    }
}